# XO ARENA — Android starter project

## Features in this starter
- Native Android Java app (min Android 6 / API 23)
- Tic-tac-toe vs computer and local two-player mode
- Profile name/avatar saved locally
- Points, theme shop, daily login reward
- Sound effects toggle stored in preferences (enabled by default)
- Sample leaderboard and a basic kids-learning section

## Build APK using GitHub Actions
1. Create a new GitHub repository and upload all files in this folder.
2. Open the **Actions** tab and enable Actions if prompted.
3. Run **Build XO ARENA APK** with **Run workflow**, or push to `main`.
4. Download the artifact named `XO-ARENA-debug-apk` from the completed workflow.
5. The APK is a debug/test build, not a Play Store release.

## Important limitations
The leaderboard uses demo data and is NOT global. Profiles, points, themes, and rewards are local to this device. Online multiplayer, account sign-in, cloud saves, parental/privacy disclosures, and administrator remote controls require a secure backend and are not implemented here. The project has not been compiled or tested on a physical device in this environment. A Gradle 8.9 installation and internet access are needed for the first cloud build.
