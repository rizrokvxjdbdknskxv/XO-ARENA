package com.nafti.xoarena;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(12,15,35), PANEL=Color.rgb(25,29,61), BLUE=Color.rgb(87,190,255), PINK=Color.rgb(255,105,202), WHITE=Color.WHITE;
    LinearLayout root, content, nav;
    android.content.SharedPreferences prefs;
    String playerName="Player", avatar="🚀", theme="NEON", mode="CPU", turn="X";
    int points=100, wins=0, losses=0, draws=0, owned=0;
    boolean sound=true, gameOver=false;
    String[] board=new String[9];
    Button[] cells=new Button[9];
    TextView status, pointsLabel;
    ToneGenerator tone;
    Random random=new Random();
    final int[][] lines={{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences("arena",MODE_PRIVATE);
        playerName=prefs.getString("name","Player"); avatar=prefs.getString("avatar","🚀");points=prefs.getInt("points",100);
        wins=prefs.getInt("wins",0);losses=prefs.getInt("losses",0);draws=prefs.getInt("draws",0);sound=prefs.getBoolean("sound",true);theme=prefs.getString("theme","NEON");
        try{tone=new ToneGenerator(AudioManager.STREAM_MUSIC,70);}catch(Exception ignored){}
        showHome();
    }
    GradientDrawable bg(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(24);d.setStroke(2,stroke);return d;}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);t.setPadding(8,8,8,8);return t;}
    Button button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setTextColor(WHITE);b.setAllCaps(false);b.setTextSize(15);b.setBackground(bg(PANEL,BLUE));b.setOnClickListener(v->action.run());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,6);b.setLayoutParams(p);return b;}
    void base(String title){root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setPadding(18,12,18,12);setContentView(root);
        TextView logo=text("✦ XO ARENA ✦",28,BLUE);logo.setTypeface(null,Typeface.BOLD);root.addView(logo);
        root.addView(text(title,16,PINK));
        ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(1);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setOrientation(0);String[] labels={"Home","Play","Profile","Shop","Rewards"};Runnable[] acts={this::showHome,this::showGame,this::showProfile,this::showShop,this::showRewards};
        for(int i=0;i<labels.length;i++){final int k=i;Button n=new Button(this);n.setText(labels[i]);n.setTextSize(10);n.setTextColor(WHITE);n.setAllCaps(false);n.setPadding(0,4,0,4);n.setBackgroundColor(PANEL);n.setOnClickListener(v->acts[k].run());nav.addView(n,new LinearLayout.LayoutParams(0,54,1));}root.addView(nav);
    }
    void save(){prefs.edit().putString("name",playerName).putString("avatar",avatar).putInt("points",points).putInt("wins",wins).putInt("losses",losses).putInt("draws",draws).putBoolean("sound",sound).putString("theme",theme).apply();}
    void addTitle(String s){TextView t=text(s,21,WHITE);t.setTypeface(null,Typeface.BOLD);content.addView(t);}
    void showHome(){base("PLAY • LEARN • WIN");content.addView(text(avatar+"  Welcome, "+playerName+"!",23,WHITE));content.addView(text("POINTS  ✦  "+points,18,BLUE));content.addView(text("Your arena starts here. Challenge the computer or play locally with a friend.",15,WHITE));
        content.addView(button("⚔  PLAY XO",this::showGame));content.addView(button("👤  PLAYER PROFILE",this::showProfile));content.addView(button("🛍  THEME SHOP",this::showShop));content.addView(button("🎁  DAILY REWARDS",this::showRewards));content.addView(button("🏆  LEADERBOARD (DEMO)",this::showLeaderboard));content.addView(button("📚  KIDS LEARNING",this::showLearning));}
    void showGame(){base("TIC-TAC-TOE ARENA");LinearLayout modes=new LinearLayout(this);modes.setOrientation(0);Button cpu=new Button(this);cpu.setText("Vs Computer");Button friend=new Button(this);friend.setText("2 Players");modes.addView(cpu,new LinearLayout.LayoutParams(0,-2,1));modes.addView(friend,new LinearLayout.LayoutParams(0,-2,1));content.addView(modes);cpu.setOnClickListener(v->{mode="CPU";resetGame();});friend.setOnClickListener(v->{mode="FRIEND";resetGame();});
        status=text("Your turn — X",18,BLUE);content.addView(status);GridLayout grid=new GridLayout(this);grid.setColumnCount(3);grid.setRowCount(3);
        for(int i=0;i<9;i++){final int j=i;Button c=new Button(this);c.setText("");c.setTextSize(36);c.setTextColor(BLUE);c.setBackground(bg(PANEL,PINK));GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(95);p.columnSpec=GridLayout.spec(i%3,1f);p.setMargins(4,4,4,4);grid.addView(c,p);cells[i]=c;c.setOnClickListener(v->move(j));}content.addView(grid);
        content.addView(button("↻  RESTART",this::resetGame));content.addView(text("Wins "+wins+"   •   Draws "+draws+"   •   Losses "+losses,15,WHITE));}
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
    void resetGame(){Arrays.fill(board,"");turn="X";gameOver=false;if(status!=null)status.setText("Your turn — X");for(Button c:cells)if(c!=null)c.setText("");}
    String winner(){for(int[] l:lines)if(board[l[0]]!=null&&board[l[0]].equals(board[l[1]])&&board[l[0]].equals(board[l[2]]))return board[l[0]];for(String s:board)if(s==null)return null;return "D";}
    void move(int i){if(gameOver||board[i]!=null)return;place(i,turn);if(checkFinish())return;if(mode.equals("CPU")){turn="O";status.setText("Computer thinking…");new android.os.Handler().postDelayed(()->{if(!gameOver)cpuMove();},300);}else{turn=turn.equals("X")?"O":"X";status.setText("Player "+turn+"'s turn");}}
    void place(int i,String s){board[i]=s;cells[i].setText(s);cells[i].setTextColor(s.equals("X")?BLUE:PINK);if(sound&&tone!=null)tone.startTone(ToneGenerator.TONE_PROP_BEEP,90);}
    void cpuMove(){Integer pick=null;for(int i=0;i<9;i++)if(board[i]==null){board[i]="O";if("O".equals(winner()))pick=i;board[i]=null;if(pick!=null)break;}if(pick==null)for(int i=0;i<9;i++)if(board[i]==null){board[i]="X";if("X".equals(winner()))pick=i;board[i]=null;if(pick!=null)break;}if(pick==null&&board[4]==null)pick=4;if(pick==null){ArrayList<Integer> e=new ArrayList<>();for(int i=0;i<9;i++)if(board[i]==null)e.add(i);if(!e.isEmpty())pick=e.get(random.nextInt(e.size()));}if(pick!=null)place(pick,"O");if(!checkFinish()){turn="X";status.setText("Your turn — X");}}
    boolean checkFinish(){String w=winner();if(w==null)return false;gameOver=true;if(w.equals("D")){draws++;points+=5;status.setText("DRAW  •  +5 points");}else if(w.equals("X")){wins++;points+=15;status.setText("YOU WIN  •  +15 points");}else{losses++;status.setText(mode.equals("CPU")?"GAME OVER — CPU WINS":"PLAYER O WINS");}save();if(sound&&tone!=null)tone.startTone(w.equals("X")?ToneGenerator.TONE_PROP_ACK:ToneGenerator.TONE_PROP_NACK,250);return true;}
    void showProfile(){base("PLAYER PROFILE");content.addView(text(avatar,58,WHITE));EditText name=new EditText(this);name.setSingleLine();name.setTextColor(WHITE);name.setHintTextColor(0xffaaaaaa);name.setHint("Player name");name.setText(playerName);content.addView(name);addTitle("Choose avatar");String[] av={"🚀","🐉","🦊","🐼","👾","⭐"};for(String a:av)content.addView(button(a,()->{avatar=a;save();showProfile();}));content.addView(button("SAVE PROFILE",()->{playerName=name.getText().toString().trim();if(playerName.isEmpty())playerName="Player";save();showProfile();}));content.addView(text("Wins: "+wins+"   Losses: "+losses+"   Draws: "+draws,16,WHITE));}
    void showShop(){base("THEME & CHARACTER SHOP");content.addView(text("Your balance: ✦ "+points,19,BLUE));String[][] items={{"NEON","Blue & purple neon","0"},{"SUNSET","Warm sunset colors","50"},{"CYBER PINK","Pink cyber glow","75"},{"GOLD","Golden champion style","100"}};for(String[] it:items)content.addView(button(it[0]+" — "+it[1]+"  •  "+it[2]+" pts",()->{int cost=Integer.parseInt(it[2]);if(theme.equals(it[0])){new AlertDialog.Builder(this).setMessage("This theme is already equipped.").setPositiveButton("OK",null).show();}else if(points<cost){new AlertDialog.Builder(this).setMessage("Not enough points yet. Win games or collect your daily reward!").setPositiveButton("OK",null).show();}else{points-=cost;theme=it[0];save();showShop();}}));content.addView(text("Selected theme: "+theme,15,PINK));}
    void showRewards(){base("DAILY REWARDS");String today=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());content.addView(text("🎁 Daily login bonus",25,PINK));content.addView(text("Collect 20 points once per day.",16,WHITE));content.addView(button("CLAIM +20 POINTS",()->{String claimed=prefs.getString("claimedDay","");if(today.equals(claimed)){new AlertDialog.Builder(this).setMessage("Today's reward has already been claimed. Come back tomorrow!").setPositiveButton("OK",null).show();}else{points+=20;prefs.edit().putString("claimedDay",today).apply();save();showRewards();}}));content.addView(text("Daily task: Play one round and earn points from the result.",15,WHITE));}
    void showLeaderboard(){base("LEADERBOARD");content.addView(text("🏆 LOCAL DEMO RANKING",21,PINK));content.addView(text("1. "+playerName+"   •   "+wins+" wins",18,WHITE));content.addView(text("2. NovaPlayer   •   12 wins",16,WHITE));content.addView(text("3. PixelFox   •   9 wins",16,WHITE));content.addView(text("This sample leaderboard is stored locally. A real global leaderboard needs an online backend and player accounts.",13,BLUE));}
    void showLearning(){base("KIDS LEARNING");content.addView(text("🔤 Arabic Letters",22,BLUE));content.addView(text("أ  ب  ت  ث  ج  ح  خ  د  ذ  ر  ز  س  ش  ص  ض  ط  ظ  ع  غ  ف  ق  ك  ل  م  ن  ه  و  ي",23,WHITE));content.addView(text("🔢 English Numbers",22,PINK));content.addView(text("Learn numbers 1 to 100. Practice saying them aloud!",16,WHITE));content.addView(button("Show a number",()->{int n=1+random.nextInt(100);new AlertDialog.Builder(this).setMessage("Number: "+n+"\nTry to say it in English!").setPositiveButton("Nice!",null).show();}));content.addView(text("📅 Months of the year",22,BLUE));content.addView(text("January • February • March • April • May • June • July • August • September • October • November • December",15,WHITE));}
    @Override protected void onDestroy(){super.onDestroy();if(tone!=null)tone.release();}
}